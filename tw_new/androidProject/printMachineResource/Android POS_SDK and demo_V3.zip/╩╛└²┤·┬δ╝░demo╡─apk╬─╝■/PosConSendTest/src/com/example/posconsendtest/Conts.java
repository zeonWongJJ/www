package com.example.posconsendtest;

import java.util.HashMap;

public class Conts {
	//public static final String ACTION_SELECT="android.net.xprinter.selectreceiver";
	public static final String ACTION_EDIT="android.net.xprinter.receiver";
	public static final String ACTION_FRAGMENT_LABEL_EDIT="android.net.xprinter.fragmentreceiver1";
	public static final String ACTION_FRAGMENT_BARCODE_EDIT="android.net.xprinter.fragmentreceiver2";
	public static final String ACTION_FRAGMENT_D2BARCODE_EDIT="android.net.xprinter.fragmentreceiver3";
	public static final String ACTION_FRAGMENT_MOBAN1_EDIT="android.net.xprinter.fragmentreceiver4";
	public static final String ACTION_FRAGMENT_MOBAN2_EDIT="android.net.xprinter.fragmentreceiver5";
	public static final String ACTION_FRAGMENT_MOBAN3_EDIT="android.net.xprinter.fragmentreceiver6";
	public static final String ACTION_FRAGMENT_MOBAN4_EDIT="android.net.xprinter.fragmentreceiver7";
	public static final String ACTION_FRAGMENT_IMAGE_EDIT="android.net.xprinter.fragmentreceiver8";
	public static final int ENABLE_BLUETOOTH=1;
	public static final int LABEL_PRINT=2;
	public static final int type_moban1=5;
	public static final int type_moban2=6;
	public static final int type_moban3=7;
	public static final int type_moban4=8;
	public static final int TAKE_PICTURE=100;
	public static final int LOAD_PICTURE_KITKAK=101;
	public static final int LOAD_PICTURE=102;
}
